---
name: wait-what
description: "Stop. That last message did not land: re-pitch it."
disable-model-invocation: true
---

Wait, I don't understand where you've got to here. Re-pitch that: give me a little bit of context you left implicit, talk in ASD-STE100 Simplified Technical English, and use the ubiquitous language from `GLOSSARY.md` — following `GLOSSARY-MAP.md` to the right one if the repo has more than one.

The point of the re-pitch is to change the framing, not the volume: the previous wording failed, so say it differently, with the context that was missing, in plainer and more technical-English phrasing, restricted to the glossary's defined terms.

## Verification

- The re-pitch adds the context the last message left implicit.
- It uses ASD-STE100 wording rather than the constructions that failed.
- It uses only terms `GLOSSARY.md` defines, drawn from the correct glossary for this repo.

## Pitfalls

- **Re-pitching in the same words that failed** only louder; the framing must change.
- **Inventing terms** instead of using the glossary's, or grabbing the wrong `GLOSSARY.md` in a multi-glossary repo.